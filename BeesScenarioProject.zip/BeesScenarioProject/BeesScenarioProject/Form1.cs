﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeesScenarioProject
{

    public partial class Form1 : Form
    {
        List<Bee> beeList;
        public Form1()
        {
            InitializeComponent();
        }

        public List<Bee> createBees(int workers, int queens, int drones)
        {
            List<Bee> bees = new List<Bee>();

            for (int x = 0; x < workers; x++)
            {
                bees.Add(new Worker());
            }
            for (int x = 0; x < queens; x++)
            {
                bees.Add(new Queen());
            }
            for (int x = 0; x < drones; x++)
            {
                bees.Add(new Drone());
            }

            return bees;
        }

        public void initialiseGrid(List<Bee> beeList)
        {
            for (int x = 0; x < dataGridView1.Rows.Count; x++)
            {
                dataGridView1.Rows[x].SetValues(x, "0%", beeList[x].GetType().Name, beeList[x].getHealth().ToString(), (beeList[x].Dead ? "dead" : "alive"));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            beeList = createBees(10, 10, 10);

            for (int x = 0; x < beeList.Count; x++)
            {
                dataGridView1.Rows.Add();
            }

            initialiseGrid(beeList);
        }

        private void DamageButton_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            
            int damage;

            for (int x = 0; x < 30; x++)
            {
                if (!beeList[x].Dead)
                {
                    damage = random.Next(0, 100);
                    beeList[x].Damage(damage);
                    dataGridView1.Rows[x].SetValues(x, damage + "%", beeList[x].GetType().Name, beeList[x].getHealth().ToString(), (beeList[x].Dead ? "dead" : "alive"));
                }
            }
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            beeList = createBees(10, 10, 10);
            initialiseGrid(beeList);
        }

        
    }
}
