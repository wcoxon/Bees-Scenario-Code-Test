﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeesScenarioProject
{
    public class Drone : Bee
    {



        public override void Damage(int damagePercent)
        {
            base.Damage(damagePercent);

            if (getHealth() < 50)
            {
                Dead = true;
            }
            return;
        }
    }
}
