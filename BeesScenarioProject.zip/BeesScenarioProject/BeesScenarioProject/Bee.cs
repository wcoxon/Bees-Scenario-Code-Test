﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeesScenarioProject
{
    public abstract class Bee
    {
        private float Health;
        public bool Dead;

        public Bee()
        {
            Health = 100;
        }

        public float getHealth()
        {
            return Health;
        }
        public virtual void Damage(int damagePercent)
        {
            if (Dead)
            {
                return;
            }

            damagePercent = Math.Max(Math.Min(damagePercent, 100), 0);
            float damageValue = (Health * damagePercent) / 100;

            Health -= damageValue;

        }

    }
}
